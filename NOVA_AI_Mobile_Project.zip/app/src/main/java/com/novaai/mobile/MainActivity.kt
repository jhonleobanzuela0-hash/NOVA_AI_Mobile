package com.novaai.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Deep = Color(0xFF090714)
private val Panel = Color(0xFF171329)
private val Violet = Color(0xFF9B7BFF)
private val Muted = Color(0xFFAAA4C2)
private val White = Color(0xFFF7F3FF)

data class ChatMessage(val text: String, val fromUser: Boolean, val time: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NovaApp() }
    }
}

@Composable
fun NovaApp() {
    val engine = remember { DemoLocalEngine() }
    val messages = remember {
        mutableStateListOf(
            ChatMessage("Hello! I'm NOVA, your offline AI prototype. My local neural model is not connected yet, but this app works without internet.", false, now())
        )
    }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        background = Deep, surface = Panel, primary = Violet,
        onBackground = White, onSurface = White
    )) {
        Column(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF17102D), Deep, Color(0xFF080711)))
            ).padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(44.dp).background(
                        Brush.linearGradient(listOf(Violet, Color(0xFF5633A5))), CircleShape
                    ),
                    contentAlignment = Alignment.Center
                ) { Text("N", fontSize = 25.sp, fontWeight = FontWeight.Black, color = White) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("NOVA AI", fontSize = 21.sp, fontWeight = FontWeight.Bold, color = White)
                    Text("PERSONAL OFFLINE ASSISTANT", fontSize = 9.sp, color = Muted, letterSpacing = 1.3.sp)
                }
                Surface(color = Color(0xFF173B32), shape = RoundedCornerShape(20.dp)) {
                    Text("● OFFLINE", Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        color = Color(0xFF78E0B5), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatusCard("ENGINE", "Demo local", Modifier.weight(1f))
                StatusCard("MODEL", "Not installed", Modifier.weight(1f))
                StatusCard("NETWORK", "Not required", Modifier.weight(1f))
            }
            Spacer(Modifier.height(16.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Your conversation", Modifier.weight(1f), color = White, fontWeight = FontWeight.SemiBold)
                TextButton(onClick = { messages.clear() }) { Text("Clear", color = Muted) }
            }

            LazyColumn(
                Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(messages) { message -> MessageBubble(message) }
                if (busy) item { Text("NOVA is thinking…", color = Muted, fontSize = 12.sp) }
            }

            Surface(color = Panel, shape = RoundedCornerShape(22.dp)) {
                Row(
                    Modifier.fillMaxWidth().padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    BasicTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f).padding(horizontal = 12.dp, vertical = 10.dp),
                        textStyle = androidx.compose.ui.text.TextStyle(color = White, fontSize = 15.sp),
                        cursorBrush = androidx.compose.ui.graphics.SolidColor(Violet),
                        decorationBox = { inner ->
                            if (input.isEmpty()) Text("Message NOVA…", color = Muted)
                            inner()
                        },
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                        keyboardActions = KeyboardActions(onSend = {
                            sendMessage(input, messages, engine, { input = it }, { busy = it }, scope)
                        })
                    )
                    Button(
                        onClick = { sendMessage(input, messages, engine, { input = it }, { busy = it }, scope) },
                        enabled = input.isNotBlank() && !busy,
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Violet)
                    ) { Text("Send", color = White) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("NOVA v0.1 • Local prototype • No account or API key",
                Modifier.align(Alignment.CenterHorizontally), color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
fun StatusCard(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Panel.copy(alpha = 0.92f), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(10.dp)) {
            Text(label, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(value, color = White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun MessageBubble(message: ChatMessage) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            Modifier.widthIn(max = 310.dp)
                .background(
                    if (message.fromUser) Color(0xFF543A91) else Panel,
                    RoundedCornerShape(18.dp)
                ).padding(13.dp)
        ) {
            Text(if (message.fromUser) "YOU" else "NOVA", color = Color(0xFFC7B7FF),
                fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(5.dp))
            Text(message.text, color = White, fontSize = 14.sp, lineHeight = 20.sp)
            Spacer(Modifier.height(5.dp))
            Text(message.time, color = Muted, fontSize = 9.sp)
        }
    }
}

private fun sendMessage(
    raw: String,
    messages: MutableList<ChatMessage>,
    engine: LocalModelEngine,
    clearInput: (String) -> Unit,
    setBusy: (Boolean) -> Unit,
    scope: kotlinx.coroutines.CoroutineScope
) {
    val text = raw.trim()
    if (text.isEmpty()) return
    messages.add(ChatMessage(text, true, now()))
    clearInput("")
    setBusy(true)
    scope.launch {
        val answer = engine.reply(text)
        messages.add(ChatMessage(answer, false, now()))
        setBusy(false)
    }
}

private fun now(): String =
    SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())

package com.novaai.mobile

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Runtime boundary for the on-device language model.
 *
 * The current v0.1 app uses DemoLocalEngine so the UI can be tested offline.
 * Replace it with an ONNX Runtime / LiteRT implementation after exporting
 * a compatible model. The existing NOVA .pth checkpoint is PyTorch-specific
 * and cannot be loaded directly by this Android app.
 */
interface LocalModelEngine {
    suspend fun reply(prompt: String): String
}

class DemoLocalEngine : LocalModelEngine {
    override suspend fun reply(prompt: String): String = withContext(Dispatchers.Default) {
        val p = prompt.lowercase()
        when {
            p.contains("hello") || p.contains("hi") ->
                "Hello! I'm NOVA. This is my offline prototype interface."
            p.contains("who are you") || p.contains("what are you") ->
                "I'm NOVA AI, an experimental assistant project. My real trained language model is not connected yet."
            p.contains("offline") ->
                "This app runs locally without internet. The current response engine is a demo, not the trained Transformer."
            p.contains("transformer") ->
                "A Transformer uses attention to process token sequences. Our next task is exporting a compatible NOVA model for Android."
            else ->
                "I received: "$prompt"\n\nI'm currently running in demo mode. Once we convert and integrate the trained NOVA model, this reply will come from the local neural network."
        }
    }
}
